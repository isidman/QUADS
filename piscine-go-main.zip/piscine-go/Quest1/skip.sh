#! /bin/bash
ls -l | sed -n 'n;p'
