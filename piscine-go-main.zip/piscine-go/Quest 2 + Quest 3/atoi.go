package student

func Atoi(s string) int {
	var n string
	for _, c := range s {
		if c >= '0' && c <= '9' {
			n += string(c)
		}
	}

	if n == "" {
		return 0
	}
	var result int
	for _, c := range n {
		result = result*10 + int(c-'0')
	}
	return result
}
